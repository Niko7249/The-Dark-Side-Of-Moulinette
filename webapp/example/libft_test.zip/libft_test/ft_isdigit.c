//ADD 42 HEADER
//NORMINETTE!!!

#include"libft.h"

int ft_isdigit(int c)
{
  if ((c >= '0' && c <= '9'))
    return (2048);
  return (0);
}
